﻿
class Program
{
    static void Main()
    {
        Console.Write("Sisesta oma nimi: ");
        string nimi = Console.ReadLine();

        if (!string.IsNullOrWhiteSpace(nimi))
        {
            Console.WriteLine($"TERE, {nimi}!");
        }
        else
        {
            Console.WriteLine("Error");
            for (int i = 0; i < 3; i++)
            {
                Console.Beep();
            }
        }
    }
}
