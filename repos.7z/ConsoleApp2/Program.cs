﻿
namespace ConsoleApp2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
            int number;

            if (int.TryParse(Console.ReadLine(), out number))
            {
                if (number == 12)
                {
                    Console.WriteLine("Number is " + number);
                }
                else if (number >= 13 && number <= 25)
                {
                    Console.WriteLine("Number is between 13 and 25");
                }
                else
                {
                    Console.WriteLine("Number is outsude range");
                }
            }
            else
            {
                Console.WriteLine("Invalid input");
            }
        }
    }
}
