﻿namespace Illiabl
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Datat types!");
            int number = 0;
            Console.WriteLine(number);
            long number2 = 2147483647;
            Console.WriteLine(number2);
            float number3 = 0.0f;
            Console.WriteLine(number3);
            double number4 = double.MaxValue;
            Console.WriteLine(number4);
            String number5 = String.Empty;
            Console.WriteLine(number5);
            bool number6 = false;
            Console.WriteLine(number6);



        }
    }
}
