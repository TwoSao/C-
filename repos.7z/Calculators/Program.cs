﻿namespace Calculators
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Calculate rectangle");
            Console.WriteLine("Enter first value");
            string firstNumber = Console.ReadLine();
            float floatfirst = float.Parse(firstNumber);
            Console.WriteLine("Enter second value");
            string secondNumber = Console.ReadLine();
            float floatSecond = float.Parse(secondNumber);
            float result = floatfirst * floatSecond;
            Console.WriteLine(result);
            float result2 = 2*(floatfirst + floatSecond);
            Console.WriteLine(result2);
        }
    }
}
