﻿namespace ConsoleApp1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Чтение возраста пользователя
            Console.WriteLine("Sisesta oma vanus:");
            int age = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine($"Teie vanus on: {age} aastat");

            if (age > 75)
            {
                Console.WriteLine("Oled pensionär.");
            }
            else if (age > 18)
            {
                Console.WriteLine("Oled töötaja.");
            }
            else if (age > 7)
            {
                Console.WriteLine("Käid koolis.");
            }
            else
            {
             Console.WriteLine("Error");
            
            }
        }
    }
}
